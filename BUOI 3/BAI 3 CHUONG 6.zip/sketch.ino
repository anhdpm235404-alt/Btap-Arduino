#include <WiFi.h>

// Thông số WiFi mặc định của Wokwi
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// Máy chủ đám mây dweet.io
const char* host = "dweet.io";

void setup() {
  Serial.begin(115200);
  delay(10);

  Serial.println();
  Serial.print("Dang ket noi den ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  // Chờ kết nối WiFi
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("Da ket noi WiFi");
  Serial.print("Dia chi IP: ");
  Serial.println(WiFi.localIP());
}

void loop() {
  delay(5000); // Đợi 5 giây mỗi lần gửi
  
  Serial.print("Dang ket noi den ");
  Serial.println(host);

  WiFiClient client;
  const int httpPort = 80;

  if (!client.connect(host, httpPort)) {
    Serial.println("Ket noi that bai ");
    return;
  }

  // Đường dẫn gửi dữ liệu đến dweet.io
  String url = "/dweet/for/my-thing-name?value=test";

  Serial.print("Dang yeu cau URL: ");
  Serial.println(url);

  // Gửi lệnh GET
  client.print(String("GET ") + url + " HTTP/1.1\r\n" +
               "Host: " + host + "\r\n" +
               "Connection: close\r\n\r\n");

  // Đợi phản hồi (Timeout 5 giây)
  unsigned long timeout = millis();
  while (client.available() == 0) {
    if (millis() - timeout > 5000) {
      Serial.println(">>> Het thoi gian client!");
      client.stop();
      return;
    }
  }

  // Đọc dữ liệu nhận về từ dweet.io
  while(client.available()){
    String line = client.readStringUntil('\r');
    Serial.print(line);
  }

  Serial.println();
  Serial.println("Dang dong ket noi ");
}