#include <WiFi.h>
#include <ESP32Servo.h>
#include <WebServer.h>


const char* ssid = "Wokwi-GUEST";
const char* password = "";

WebServer server(80);
Servo sg90;
const int servoPin = 18;

// Giao diện Trang Web đơn giản có thanh trượt điều khiển
void handleRoot() {
  String html = "<!DOCTYPE html><html><head>";
  html += "<meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += "<style>body{font-family:Arial; text-align:center; margin-top:50px;}";
  html += ".slider{width:300px;}</style></head><body>";
  html += "<h2>Điều Khiển Servo Qua Web (ESP32)</h2>";
  html += "<p>Góc quay hiện tại: <b id='angleVal'>90</b>&deg;</p>";
  html += "<input type='range' min='0' max='180' value='90' class='slider' oninput='updateServo(this.value)'>";
  html += "<script>";
  html += "function updateServo(val) {";
  html += "  document.getElementById('angleVal').innerText = val;";
  html += "  fetch('/setAngle?val=' + val);";
  html += "}";
  html += "</script></body></html>";
  
  server.send(200, "text/html", html);
}

// Xử lý sự kiện khi dịch chuyển thanh trượt trên Web
void handleSetAngle() {
  if (server.hasArg("val")) {
    int angle = server.arg("val").toInt();
    sg90.write(angle);
    server.send(200, "text/plain", "OK");
  }
}

void setup() {
  Serial.begin(115200);
  
  // Cấu hình chân Servo
  sg90.attach(servoPin);
  sg90.write(90); // Đặt góc mặc định 90 độ

  // Kết nối Wi-Fi Wokwi
  WiFi.begin(ssid, password);
  Serial.print("Dang ket noi WiFi...");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  
  Serial.println("\nDa ket noi WiFi thanh cong!");
  Serial.print("Truy cap Web qua dia chi IP: ");
  Serial.println(WiFi.localIP());

  // Thiết lập đường dẫn Web Server
  server.on("/", handleRoot);
  server.on("/setAngle", handleSetAngle);
  server.begin();
}

void loop() {
  server.handleClient();
}