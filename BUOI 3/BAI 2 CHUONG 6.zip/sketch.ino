#include <WiFi.h>
#include <PubSubClient.h>

#define LED_PIN 5

const char* ssid = "Wokwi-GUEST";
const char* password = "";
const char* mqtt_server = "broker.hivemq.com";
const char* topic_nhietdo = "khoa_iot/nhietdo";

WiFiClient espClient;
PubSubClient client(espClient);

void callback(char* topic, byte* payload, unsigned int length) {
  String tempStr = "";
  for (int i = 0; i < length; i++) tempStr += (char)payload[i];
  float temp = tempStr.toFloat();

  if (temp > 30.0) {
    digitalWrite(LED_PIN, HIGH); // Nhiệt độ > 30°C -> Bật LED
  } else {
    digitalWrite(LED_PIN, LOW);  // Nhiệt độ <= 30°C -> Tắt LED
  }
}

void setup() {
  pinMode(LED_PIN, OUTPUT);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) delay(500);

  client.setServer(mqtt_server, 1883);
  client.setCallback(callback);
}

void loop() {
  if (!client.connected()) {
    if (client.connect("ESP32_Sub_LED")) {
      client.subscribe(topic_nhietdo);
    } else {
      delay(2000);
    }
  }
  client.loop();
}