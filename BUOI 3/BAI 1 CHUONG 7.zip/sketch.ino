int nutNhan = 4;
int led = 2;

void setup() {
  pinMode(nutNhan, INPUT_PULLUP);
  pinMode(led, OUTPUT);
}

void loop() {
  int trangThai = digitalRead(nutNhan);

  if (trangThai == LOW) {
    digitalWrite(led, HIGH);
  }
  else {
    digitalWrite(led, LOW);
  }

  delay(100);
}