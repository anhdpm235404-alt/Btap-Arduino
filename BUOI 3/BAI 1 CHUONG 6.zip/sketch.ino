// Chân nối với LED
int ledPin = 5;

void setup() {
  pinMode(ledPin, OUTPUT);
}

void loop() {
  // LED tắt
  digitalWrite(ledPin, LOW);
  delay(1000);
  
  // LED sáng
  digitalWrite(ledPin, HIGH);
  delay(2000);
}