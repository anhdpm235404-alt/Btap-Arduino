int ledPin = 4;        // Chân nối LED
int fadeValue = 1023;  // Hệ số đóng

void setup() {
  pinMode(ledPin, OUTPUT);
}

void loop() {
  // Bật LED sáng
  analogWrite(ledPin, fadeValue);
  
  // Giảm hệ số đóng đi 1 đơn vị
  if(fadeValue > 0) fadeValue--;
  delay(5);
}