#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

// Khai báo màn hình SSD1306 kết nối qua I2C
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
void setup() {
  Serial.begin(115200);

  // Thêm dòng này để khai báo SDA = GPIO 32, SCL = GPIO 23
  Wire.begin(32, 23);

  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("Không tìm thấy màn hình OLED SSD1306!"));
    for (;;);
  }

  display.clearDisplay();

  // Dòng chữ thứ nhất
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 10);
  display.println("Xin chao Wokwi!");

  // Dòng chữ thứ hai
  display.setTextSize(2);
  display.setCursor(0, 30);
  display.println("ESP32 OLED");

  display.display();
}

void loop() {
  // Chương trình chạy lặp lại ở đây nếu cần
}