import network
import time
from machine import Pin
from umqtt.simple import MQTTClient

# Khởi tạo LED cảnh báo tại GPIO 2
led = Pin(2, Pin.OUT)
led.value(0)

# Cấu hình WiFi Wokwi
WIFI_SSID = "Wokwi-GUEST"
WIFI_PASSWORD = ""

# Cấu hình Adafruit IO
MQTT_BROKER = "io.adafruit.com"
MQTT_PORT = 1883
MQTT_USER = "ndhuy412"
MQTT_PASSWORD = "aio_AnxZ97YyrI7SUkZgR1Sy45uV623n"
MQTT_TOPIC = "ndhuy412/feeds/temperature"
CLIENT_ID = "ESP32_LED_Alert"

# Ngưỡng nhiệt độ kích hoạt cảnh báo
TEMP_THRESHOLD = 50.0

def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if not wlan.isconnected():
        print("Dang ket noi WiFi...", end="")
        wlan.connect(WIFI_SSID, WIFI_PASSWORD)
        while not wlan.isconnected():
            print(".", end="")
            time.sleep(0.3)
    print("\nWiFi da ket noi! IP:", wlan.ifconfig()[0])

def on_message(topic, msg):
    try:
        payload = msg.decode("utf-8")
        temp = float(payload)
        print("LED Board nhan duoc:", temp, "*C")

        # Kiem tra nguong canh bao
        if temp >= TEMP_THRESHOLD:
            led.value(1)
            print(">> CANH BAO: Nhiet do vuot nguong (>= 50*C)! LED BAT <<")
        else:
            led.value(0)
            print("Nhiet do binh thuong (< 50*C). LED TAT.")
    except ValueError:
        print("Gia tri nhan duoc khong hop le:", msg)

def connect_mqtt():
    client = MQTTClient(
        client_id=CLIENT_ID,
        server=MQTT_BROKER,
        port=MQTT_PORT,
        user=MQTT_USER,
        password=MQTT_PASSWORD,
        keepalive=60
    )
    client.set_callback(on_message)
    print("Dang ket noi Adafruit IO...")
    client.connect()
    client.subscribe(MQTT_TOPIC)
    print("Da Subscribe topic:", MQTT_TOPIC)
    print("He thong canh bao san sang!")
    return client

# Khởi chạy kết nối
connect_wifi()

client = None
while client is None:
    try:
        client = connect_mqtt()
    except Exception as e:
        print("Loi ket noi MQTT, thu lai sau 2 giay...", e)
        time.sleep(2)

# Vòng lặp nhận dữ liệu
while True:
    try:
        client.check_msg()
    except Exception as e:
        print("Mat ket noi MQTT, dang thu lai...", e)
        try:
            client = connect_mqtt()
        except:
            pass
    time.sleep(0.1)