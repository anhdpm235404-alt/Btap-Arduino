// Chân LED
int ledPin = 5;

void setup() {
  pinMode(ledPin, OUTPUT);
}

void loop() {
  // LED sáng
  digitalWrite(ledPin, HIGH);
  delay(1000);
  
  // LED tắt
  digitalWrite(ledPin, LOW);
  delay(1000);
}